package gimnasio.Designs;

import gimnasio.GestorDeInstancias;
import gimnasio.SalaPesas;
//import gimnasio.ModuloSalaPesas;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class WindowsSalaDePesas extends javax.swing.JFrame {

    GestorDeInstancias gestor;
    private SalaPesas salaPesas;

    public WindowsSalaDePesas(GestorDeInstancias gestor) {
        this.gestor = gestor;
        this.salaPesas = gestor.getSalaPesas();
        setUndecorated(true); // quita la barra superior y bordes del sistema

        // Inicializar los componentes de la ventana
        initComponents();

        // Centrar la ventana
        setLocationRelativeTo(null); // opcional: centrar ventana

        // Hacer visible
        setVisible(true);

        // Aplicar forma redondeada (después de visible)
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 60, 60));
        btnSalir.addActionListener(e -> dispose());

        cargarDatosSalaPesas();
    
    }

    private void cargarDatosSalaPesas() {
        DefaultTableModel model = (DefaultTableModel) tablaSalaPesas.getModel();
        model.setRowCount(0); // Limpiar filas existentes
        SalaPesas sala = gestor.getSalaPesas();
        if (sala != null) {
            model.addRow(new Object[]{
                sala.getCapacidadMaxima(),
                sala.getPersonasActuales(),
                sala.getEspaciosDisponibles()
            });
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnMinimi = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        btnClaesGrupales = new javax.swing.JButton();
        btnCabinaInsonorizada = new javax.swing.JButton();
        btnAuditorioFitnes = new javax.swing.JButton();
        btnSalaPesas = new javax.swing.JButton();
        btnAreasRecreacion = new javax.swing.JButton();
        btnParqueo = new javax.swing.JButton();
        btnSocios = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtIdSocio = new javax.swing.JTextField();
        btnIngresar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btnVerSocios = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaSalaPesas = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnMinimi.setText("minimi");
        btnMinimi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMinimiActionPerformed(evt);
            }
        });

        btnSalir.setText("salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(171, 251, 211));

        btnClaesGrupales.setText("Clases Grupales");
        btnClaesGrupales.setBorder(null);
        btnClaesGrupales.setContentAreaFilled(false);
        btnClaesGrupales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClaesGrupalesActionPerformed(evt);
            }
        });

        btnCabinaInsonorizada.setText("Cabinas Insonorizada");
        btnCabinaInsonorizada.setBorder(null);
        btnCabinaInsonorizada.setContentAreaFilled(false);
        btnCabinaInsonorizada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCabinaInsonorizadaActionPerformed(evt);
            }
        });

        btnAuditorioFitnes.setText("Auditorio Fitnes");
        btnAuditorioFitnes.setBorder(null);
        btnAuditorioFitnes.setContentAreaFilled(false);
        btnAuditorioFitnes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuditorioFitnesActionPerformed(evt);
            }
        });

        btnSalaPesas.setBackground(new java.awt.Color(163, 238, 201));
        btnSalaPesas.setText("Sala De Pesas");
        btnSalaPesas.setBorder(null);
        btnSalaPesas.setContentAreaFilled(false);
        btnSalaPesas.setOpaque(true);
        btnSalaPesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalaPesasActionPerformed(evt);
            }
        });

        btnAreasRecreacion.setText("Espacios De Recreación");
        btnAreasRecreacion.setBorder(null);
        btnAreasRecreacion.setContentAreaFilled(false);
        btnAreasRecreacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAreasRecreacionActionPerformed(evt);
            }
        });

        btnParqueo.setBackground(new java.awt.Color(171, 251, 211));
        btnParqueo.setText("Parqueo");
        btnParqueo.setBorder(null);
        btnParqueo.setContentAreaFilled(false);
        btnParqueo.setOpaque(true);
        btnParqueo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnParqueoActionPerformed(evt);
            }
        });

        btnSocios.setText("Socios");
        btnSocios.setBorder(null);
        btnSocios.setContentAreaFilled(false);
        btnSocios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSociosActionPerformed(evt);
            }
        });

        jLabel1.setText("Sala de pesas ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnParqueo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnAreasRecreacion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnSalaPesas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnAuditorioFitnes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnCabinaInsonorizada, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnClaesGrupales, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnSocios, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(122, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(118, 118, 118))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel1)
                .addGap(35, 35, 35)
                .addComponent(btnParqueo, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(btnSocios, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnClaesGrupales, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCabinaInsonorizada, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAuditorioFitnes, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSalaPesas, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAreasRecreacion, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(127, Short.MAX_VALUE))
        );

        btnIngresar.setText("Ingresar");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });

        jButton1.setText("Salida");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnVerSocios.setText("Visulizar socios");
        btnVerSocios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerSociosActionPerformed(evt);
            }
        });

        jLabel5.setText("ID del socio");

        tablaSalaPesas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Capacidad Maxima", "Socios actuales", "Espacios disponibles"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaSalaPesas);
        if (tablaSalaPesas.getColumnModel().getColumnCount() > 0) {
            tablaSalaPesas.getColumnModel().getColumn(0).setResizable(false);
            tablaSalaPesas.getColumnModel().getColumn(1).setResizable(false);
            tablaSalaPesas.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(376, 376, 376)
                                .addComponent(jLabel5)
                                .addGap(34, 34, 34)
                                .addComponent(txtIdSocio, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnMinimi)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSalir)
                        .addGap(11, 11, 11))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 192, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 585, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(150, 150, 150))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(247, 247, 247)
                        .addComponent(btnIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnVerSocios, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalir)
                    .addComponent(btnMinimi))
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdSocio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnIngresar)
                            .addComponent(jButton1)
                            .addComponent(btnVerSocios))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMinimiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMinimiActionPerformed
        setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_btnMinimiActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnClaesGrupalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClaesGrupalesActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsClasesGrupales clases = new WindowsClasesGrupales(gestor);
        clases.setVisible(true);
    }//GEN-LAST:event_btnClaesGrupalesActionPerformed

    private void btnCabinaInsonorizadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCabinaInsonorizadaActionPerformed
        this.dispose(); // Esto cierra la ventana actual
        WindowsCabinasInsonorizadas cabina = new WindowsCabinasInsonorizadas(gestor);
        cabina.setVisible(true);

    }//GEN-LAST:event_btnCabinaInsonorizadaActionPerformed

    private void btnAuditorioFitnesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAuditorioFitnesActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsAuditorioFitnes audiroio = new WindowsAuditorioFitnes(gestor);
        audiroio.setVisible(true);
    }//GEN-LAST:event_btnAuditorioFitnesActionPerformed

    private void btnSalaPesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalaPesasActionPerformed
        this.dispose(); // Cierra la ventana actual
        WindowsSalaDePesas pesas = new WindowsSalaDePesas(gestor); // Pasa el gestor de instancias
        pesas.setVisible(true);
    }//GEN-LAST:event_btnSalaPesasActionPerformed

    private void btnAreasRecreacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAreasRecreacionActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsSalasDeRecreacion recreacion = new WindowsSalasDeRecreacion(gestor);
        recreacion.setVisible(true);
    }//GEN-LAST:event_btnAreasRecreacionActionPerformed

    private void btnParqueoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnParqueoActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsParqueo parqueo = new WindowsParqueo(gestor);
        parqueo.setVisible(true);
    }//GEN-LAST:event_btnParqueoActionPerformed

    private void btnSociosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSociosActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsSocios socios = new WindowsSocios(gestor);
        socios.setVisible(true);
    }//GEN-LAST:event_btnSociosActionPerformed

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
        String idSocio = txtIdSocio.getText().trim();
        if (idSocio.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese el ID del socio.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!gestor.verificarID(idSocio)) {
            JOptionPane.showMessageDialog(this, "El ID de socio no existe.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        SalaPesas sala = gestor.getSalaPesas();
        if (sala != null) {
            if (sala.ingresarSocio(idSocio)) {
                cargarDatosSalaPesas(); // Actualizar la tabla
            }
        } else {
            JOptionPane.showMessageDialog(this, "Error: Sala de Pesas no inicializada.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btnIngresarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String idSocio = txtIdSocio.getText().trim();
        if (idSocio.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese el ID del socio.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        SalaPesas sala = gestor.getSalaPesas();
        if (sala != null) {
            if (sala.salirSocio(idSocio)) {
                cargarDatosSalaPesas(); // Actualizar la tabla
            }
        } else {
            JOptionPane.showMessageDialog(this, "Error: Sala de Pesas no inicializada.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnVerSociosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerSociosActionPerformed
        SalaPesas sala = gestor.getSalaPesas();
        if (sala != null) {
            sala.mostrarSociosEnSala(gestor.getSocios());
        } 
    }//GEN-LAST:event_btnVerSociosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAreasRecreacion;
    private javax.swing.JButton btnAuditorioFitnes;
    private javax.swing.JButton btnCabinaInsonorizada;
    private javax.swing.JButton btnClaesGrupales;
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnMinimi;
    private javax.swing.JButton btnParqueo;
    private javax.swing.JButton btnSalaPesas;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnSocios;
    private javax.swing.JButton btnVerSocios;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaSalaPesas;
    private javax.swing.JTextField txtIdSocio;
    // End of variables declaration//GEN-END:variables
}
