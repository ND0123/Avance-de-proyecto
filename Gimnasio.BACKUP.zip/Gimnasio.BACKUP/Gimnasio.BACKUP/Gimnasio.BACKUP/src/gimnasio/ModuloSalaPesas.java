/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gimnasio;

import javax.swing.JOptionPane;

/**
 *
 * @author XPC
 */
  /*
public class ModuloSalaPesas {

  
    public static void ejecutar(GestorDeInstancias gestor) {
        SalaPesas sp = gestor.getSalaPesas();
        if (sp == null) {
            JOptionPane.showMessageDialog(null, "Módulo de Sala de Pesas no disponible.");
            return;
        }

        while (true) {
            String in = JOptionPane.showInputDialog("SALA DE PESAS\n\n"
                    + "1. Ingresar socio\n"
                    + "2. Salida de socio\n"
                    + "3. Ver cantidad actual\n"
                    + "0. Volver");
            
            if (in == null || in.trim().equals("0")) {
                return;
            }

            switch (in.trim()) {
                case "1": { // Ingresar
                    String id = JOptionPane.showInputDialog("ID del socio para ingresar:");
                    if (id == null) {
                        break;
                    }
                    Socio s = gestor.buscarSocio(id.trim());
                    if (s == null || !s.isActivo()) {
                        JOptionPane.showMessageDialog(null, "Socio no encontrado o inactivo.");
                        break;
                    }
                    sp.ingresar(id.trim());
                    JOptionPane.showMessageDialog(null, "Ingreso exitoso para: " + s.getNombre());
                    break;
                }
                case "2": { // Salir
                    String id = JOptionPane.showInputDialog("ID del socio para salir:");
                    if (id == null) {
                        break;
                    }
                    sp.salir(id.trim());
                    JOptionPane.showMessageDialog(null, "Salida registrada para: " + id.trim());
                    break;
                }
                case "3": { // Ver cantidad
                    int cantidad = sp.getCantidadActual();
                    JOptionPane.showMessageDialog(null, "Personas en sala de pesas: " + cantidad);
                    break;
                }
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        }
    }
}
*/