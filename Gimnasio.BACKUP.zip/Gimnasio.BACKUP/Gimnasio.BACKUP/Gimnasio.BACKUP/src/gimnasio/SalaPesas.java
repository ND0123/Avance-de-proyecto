package gimnasio;

import javax.swing.JOptionPane;

public class SalaPesas {

    private int capacidadMaxima;
    private int personasActuales;
    private String[] sociosDentro; // Para almacenar los IDs de los socios actualmente en la sala

    public SalaPesas(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
        this.personasActuales = 0;
        this.sociosDentro = new String[capacidadMaxima]; // Inicializa el array con la capacidad máxima
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public int getPersonasActuales() {
        return personasActuales;
    }

    public int getEspaciosDisponibles() {
        return capacidadMaxima - personasActuales;
    }

    // Metodo para que un socio ingrese a la sala
    public boolean ingresarSocio(String idSocio) {
        if (personasActuales >= capacidadMaxima) {
            JOptionPane.showMessageDialog(null, "Sala llena");
            return false;
        }

        for (int i = 0; i < personasActuales; i++) {
            if (sociosDentro[i] != null && sociosDentro[i].equals(idSocio)) {
                JOptionPane.showMessageDialog(null, "El socio con ID " + idSocio + " ya se encuentra en la sala de pesas.");
                return false;
            }
        }
        sociosDentro[personasActuales] = idSocio;
        personasActuales++;
        JOptionPane.showMessageDialog(null, "Socio con ID " + idSocio + " ha ingresado a la sala de pesas, espacios disponibles " + getEspaciosDisponibles());
        return true;
    }

    // Metodo para que un socio salga de la sala
    public boolean salirSocio(String idSocio) {
        if (personasActuales == 0) {
            JOptionPane.showMessageDialog(null, "La sala de pesas está vacía.");
            return false;
        }
        // Buscar y remover al socio
        for (int i = 0; i < personasActuales; i++) {
            if (sociosDentro[i] != null && sociosDentro[i].equals(idSocio)) {
                // Mover los elementos restantes para llenar el hueco
                for (int j = i; j < personasActuales - 1; j++) {
                    sociosDentro[j] = sociosDentro[j + 1];
                }
                sociosDentro[personasActuales - 1] = null; // Limpiar la última posición
                personasActuales--;
                JOptionPane.showMessageDialog(null, "Socio con ID " + idSocio + " ha salido de la sala de pesas. Espacios disponibles: " + getEspaciosDisponibles());
                return true;
            }
        }
        JOptionPane.showMessageDialog(null, "El socio con ID " + idSocio + " no se encuentra en la sala de pesas.");
        return false;
    }

    // Metodo para mostrar los socios actualmente en la sala
    public void mostrarSociosEnSala(Socio[] todosLosSocios) {
        if (personasActuales == 0) {
            JOptionPane.showMessageDialog(null, "No hay socios actualmente en la sala de pesas.");
            return;
        }
        StringBuilder lista = new StringBuilder("Socios actualmente en la sala de pesas:");
        for (int i = 0; i < personasActuales; i++) {
            String id = sociosDentro[i];
            String nombre = buscarNombrePorID(id, todosLosSocios); 
            lista.append("- ").append(id).append(" (").append(nombre).append("");
        }
        JOptionPane.showMessageDialog(null, lista.toString());
    }

    private String buscarNombrePorID(String id, Socio[] socios) {
        if (socios == null) {
            return "Nombre no encontrado";
        }
        for (Socio socio : socios) {
            if (socio != null && socio.getId().equals(id)) {
                return socio.getNombre();
            }
        }
        return "Nombre no encontrado";
    }

    @Override
    public String toString() {
        return "SalaPesas{"
                + "capacidadMaxima=" + capacidadMaxima
                + ", personasActuales=" + personasActuales;
    }
    /* ??? Borrar esto 
    private final int CAPACIDAD_MAXIMA = 50;
    private String[] personasEnSala = new String[CAPACIDAD_MAXIMA];
    private int cantidadActual = 0;

    public void ingresar(String id) {
        if (cantidadActual >= CAPACIDAD_MAXIMA) {
            JOptionPane.showMessageDialog(null, "La sala está llena.");
            return;
        }
        if (estaDentro(id)) {
            JOptionPane.showMessageDialog(null, "El socio ya está en la sala.");
            return;
        }
        personasEnSala[cantidadActual++] = id;
        JOptionPane.showMessageDialog(null, "Ingreso registrado.");
    }

    public void salir(String id) {
        int index = -1;
        for (int i = 0; i < cantidadActual; i++) {
            if (personasEnSala[i].equalsIgnoreCase(id)) {
                index = i;
                break;
            }
        }

        if (index != -1) {
            for (int i = index; i < cantidadActual - 1; i++) {
                personasEnSala[i] = personasEnSala[i + 1];
            }
            personasEnSala[--cantidadActual] = null;
            JOptionPane.showMessageDialog(null, "Salida registrada.");
        } else {
            JOptionPane.showMessageDialog(null, "El socio no estaba en la sala.");
        }
    }

    public void mostrarCantidad() {
        JOptionPane.showMessageDialog(null, "Personas en la sala: " + cantidadActual);
    }

    private boolean estaDentro(String id) {
        for (int i = 0; i < cantidadActual; i++) {
            if (personasEnSala[i].equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }
    public int getCantidadActual() {
        return cantidadActual;
    }
    
     */
}
