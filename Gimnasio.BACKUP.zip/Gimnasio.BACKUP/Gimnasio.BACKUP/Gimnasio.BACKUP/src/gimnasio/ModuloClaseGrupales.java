package gimnasio;

import javax.swing.JOptionPane;

public class ModuloClaseGrupales { 

    public static void ejecutar(GestorDeInstancias gestor) {
        
        ClaseGrupal[] clases = gestor.getClaseGrupal();
        inicializarClasesSiHaceFalta(clases);

        while (true) {
            String in = JOptionPane.showInputDialog(
                "GESTIÓN DE CLASES GRUPALES\n\n" +
                "1. Ver clases disponibles\n" +
                "2. Inscribir socio en clase\n" +
                "3. Cancelar inscripción\n" +
                "4. Ver inscritos\n" +
                "5. Volver al menú principal"
            );
            if (in == null) return; // cerrado
            int subopcion;
            try { subopcion = Integer.parseInt(in.trim()); }
            catch (NumberFormatException e) { JOptionPane.showMessageDialog(null, "Opción inválida"); continue; }

            switch (subopcion) {
                case 1:
                    mostrarClasesDisponibles(clases);
                    break;
                case 2: {
                    Integer idx = pedirIndiceClase("Ingrese el número de la clase (1-6):");
                    if (idx == null) break;
                    if (clases[idx] == null) { JOptionPane.showMessageDialog(null, "Clase no inicializada."); break; }
                    String id = JOptionPane.showInputDialog("ID del socio:");
                    if (id == null) break;
                    if (!gestor.verificarID(id.trim())) { JOptionPane.showMessageDialog(null, "ID de socio no existe."); break; }
                    clases[idx].registrarSocio(id.trim());
                    break;
                }
                case 3: {
                    Integer idx = pedirIndiceClase("Ingrese el número de la clase (1-6):");
                    if (idx == null) break;
                    if (clases[idx] == null) { JOptionPane.showMessageDialog(null, "Clase no inicializada."); break; }
                    String idCancelar = JOptionPane.showInputDialog("ID del socio a cancelar:");
                    if (idCancelar == null) break;
                    clases[idx].cancelarReserva(idCancelar.trim());
                    break;
                }
                case 4: {
                    Integer idx = pedirIndiceClase("Ingrese el número de la clase (1-6):");
                    if (idx == null) break;
                    if (clases[idx] == null) { JOptionPane.showMessageDialog(null, "Clase no inicializada."); break; }
                    clases[idx].mostrarInscritos();
                    break;
                }
                case 5:
                    return; // salir al menú principal
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida");
            }
        }
    }

    private static Integer pedirIndiceClase(String prompt) {
        String s = JOptionPane.showInputDialog(prompt);
        if (s == null) return null;
        try {
            int n = Integer.parseInt(s.trim());
            if (n < 1 || n > 6) { JOptionPane.showMessageDialog(null, "Debe estar entre 1 y 6."); return null; }
            return n - 1;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Número inválido.");
            return null;
        }
    }

    private static void inicializarClasesSiHaceFalta(ClaseGrupal[] clases) {
        if (clases[0] == null) {
            clases[0] = new ClaseGrupal("Yoga", "7:00 AM", 10);
            clases[1] = new ClaseGrupal("Zumba", "8:00 AM", 15);
            clases[2] = new ClaseGrupal("Pilates", "9:00 AM", 12);
            clases[3] = new ClaseGrupal("Crossfit", "6:00 PM", 12);
            clases[4] = new ClaseGrupal("Funcional", "7:00 PM", 10);
            clases[5] = new ClaseGrupal("Step", "8:00 PM", 15);
        }
    }

    private static void mostrarClasesDisponibles(ClaseGrupal[] clases) {
        StringBuilder listado = new StringBuilder("CLASES DISPONIBLES\n\n");
        listado.append(" MAÑANA:\n");
        for (int i = 0; i < 3; i++) {
            if (clases[i] != null) {
                listado.append(i + 1).append(". ").append(clases[i].getNombre()).append(" - ")
                       .append(clases[i].getHorario()).append(" - Cupos disponibles: ")
                       .append(clases[i].getCuposDisponibles()).append("\n");
            }
        }
        listado.append("\n NOCHE:\n");
        for (int i = 3; i < 6; i++) {
            if (clases[i] != null) {
                listado.append(i + 1).append(". ").append(clases[i].getNombre()).append(" - ")
                       .append(clases[i].getHorario()).append(" - Cupos disponibles: ")
                       .append(clases[i].getCuposDisponibles()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, listado.toString());
    }
}
