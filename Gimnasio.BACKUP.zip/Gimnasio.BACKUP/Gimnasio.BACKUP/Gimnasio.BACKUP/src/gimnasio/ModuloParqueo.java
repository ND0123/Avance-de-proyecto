/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gimnasio;

import javax.swing.JOptionPane;

/**
 *
 * @author XPC
 */
public class ModuloParqueo {

        public static void ejecutar(GestorDeInstancias gestor) {
        Parqueo p = gestor.getParqueo();
        if (p == null) {
            JOptionPane.showMessageDialog(null, "No hay módulo de parqueo disponible.");
            return;
        }

        while (true) {
            String in = JOptionPane.showInputDialog(
                "PARQUEO\n\n" +
                "1. Ver parqueos\n" +
                "2. Asignar parqueo\n" +
                "0. Volver"
            );
            if (in == null || in.trim().equals("0")) {
                return;
            }

            switch (in.trim()) {
                case "1": {
                    p.mostrarTodo();
                    break;
                }

                case "2": {
                    // ID socio
                    String id = JOptionPane.showInputDialog("ID del socio:");
                    if (id == null) {
                        break;
                    }
                    id = id.trim();
                    if (id.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "ID vacío.");
                        break;
                    }

                    Socio s = gestor.buscarSocio(id);
                    if (s == null || !s.isActivo()) {
                        JOptionPane.showMessageDialog(null, "Socio no encontrado o inactivo.");
                        break;
                    }

                    // Nivel
                    String nivel = JOptionPane.showInputDialog("Nivel (G1, G2, G3):");
                    if (nivel == null) {
                        break;
                    }
                    nivel = nivel.trim();
                    if (nivel.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Nivel inválido.");
                        break;
                    }

                    // Fila
                    String fila = JOptionPane.showInputDialog("Fila (A-F):");
                    if (fila == null || fila.isEmpty()) {
                        break;
                    }
                    char filaParqueo = Character.toUpperCase(fila.charAt(0));

                    // Columna
                    String columna = JOptionPane.showInputDialog("Columna (1-5):");
                    if (columna == null) {
                        break;
                    }
                    int col;
                    try {
                        col = Integer.parseInt(columna.trim());
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Columna inválida.");
                        break;
                    }

                    boolean ok = p.asignarEspacio(nivel, filaParqueo, col);
                    if (ok) {
                        JOptionPane.showMessageDialog(null, "Parqueo asignado.");
                    } else {
                        JOptionPane.showMessageDialog(null, "No se pudo asignar.");
                    }
                    break;
                }

                default: {
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
                    break;
                }
            }
        }
    }
}
