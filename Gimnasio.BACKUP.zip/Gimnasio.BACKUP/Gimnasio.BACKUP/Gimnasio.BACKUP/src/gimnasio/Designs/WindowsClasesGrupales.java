package gimnasio.Designs;

import gimnasio.ClaseGrupal;
import static gimnasio.Designs.MainWindows.gestor;
import gimnasio.GestorDeInstancias;
import gimnasio.ModuloClaseGrupales;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class WindowsClasesGrupales extends javax.swing.JFrame {

    GestorDeInstancias gestor;

    public WindowsClasesGrupales(GestorDeInstancias gestor) {
        this.gestor = gestor;
        setUndecorated(true); // quita la barra superior y bordes del sistema

        // Inicializar los componentes de la ventana
        initComponents();

        // Centrar la ventana
        setLocationRelativeTo(null); // opcional: centrar ventana

        // Hacer visible
        setVisible(true);

        // Aplicar forma redondeada (después de visible)
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 60, 60));
        btnSalir.addActionListener(e -> dispose());

        DefaultTableModel model = (DefaultTableModel) tablaClases.getModel();
        model.setRowCount(0); // Limpiar filas existentes
        cargarClasesEnTabla();
    }

    private void cargarClasesEnTabla() {
        DefaultTableModel model = (DefaultTableModel) tablaClases.getModel();
        model.setRowCount(0); // Limpiar tabla
        ClaseGrupal[] clases = gestor.getClaseGrupal();

        for (ClaseGrupal clase : gestor.getClaseGrupal()) {
            if (clase != null) {
                model.addRow(new Object[]{
                    clase.getNombre(),
                    clase.getHorario(),
                    clase.getCapacidadMaxima(),
                    clase.getCantidadActual(),
                    clase.getCuposDisponibles()
                });
            }
        }
    }

    private void actualizarTablaClases() {
        DefaultTableModel model = (DefaultTableModel) tablaClases.getModel();
        model.setRowCount(0); // Limpiar filas existentes
        ClaseGrupal[] clases = gestor.getClaseGrupal();
        if (clases != null) {
            for (ClaseGrupal clase : clases) {
                model.addRow(new Object[]{
                    clase.getNombre(),
                    clase.getHorario(),
                    clase.getCapacidadMaxima(),
                    clase.getCuposDisponibles()
                });
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnMinimi = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        btnClaesGrupales = new javax.swing.JButton();
        btnCabinaInsonorizada = new javax.swing.JButton();
        btnAuditorioFitnes = new javax.swing.JButton();
        btnSalaPesas = new javax.swing.JButton();
        btnAreasRecreacion = new javax.swing.JButton();
        sss = new javax.swing.JButton();
        btnSocios = new javax.swing.JButton();
        btnParqueo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaClases = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtNombreClase = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();
        txtIdSocio = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnMinimi.setText("minimi");
        btnMinimi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMinimiActionPerformed(evt);
            }
        });

        btnSalir.setText("salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(171, 251, 211));

        btnClaesGrupales.setBackground(new java.awt.Color(163, 238, 201));
        btnClaesGrupales.setText("Clases Grupales");
        btnClaesGrupales.setBorder(null);
        btnClaesGrupales.setContentAreaFilled(false);
        btnClaesGrupales.setOpaque(true);
        btnClaesGrupales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClaesGrupalesActionPerformed(evt);
            }
        });

        btnCabinaInsonorizada.setText("Cabinas Insonorizada");
        btnCabinaInsonorizada.setBorder(null);
        btnCabinaInsonorizada.setContentAreaFilled(false);
        btnCabinaInsonorizada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCabinaInsonorizadaActionPerformed(evt);
            }
        });

        btnAuditorioFitnes.setText("Auditorio Fitnes");
        btnAuditorioFitnes.setBorder(null);
        btnAuditorioFitnes.setContentAreaFilled(false);
        btnAuditorioFitnes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuditorioFitnesActionPerformed(evt);
            }
        });

        btnSalaPesas.setText("Sala De Pesas");
        btnSalaPesas.setBorder(null);
        btnSalaPesas.setContentAreaFilled(false);
        btnSalaPesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalaPesasActionPerformed(evt);
            }
        });

        btnAreasRecreacion.setText("Espacios De Recreación");
        btnAreasRecreacion.setBorder(null);
        btnAreasRecreacion.setContentAreaFilled(false);
        btnAreasRecreacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAreasRecreacionActionPerformed(evt);
            }
        });

        sss.setBackground(new java.awt.Color(163, 238, 201));
        sss.setText("Clases Grupales");
        sss.setBorder(null);
        sss.setContentAreaFilled(false);
        sss.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sssActionPerformed(evt);
            }
        });

        btnSocios.setText("Socios");
        btnSocios.setBorder(null);
        btnSocios.setContentAreaFilled(false);
        btnSocios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSociosActionPerformed(evt);
            }
        });

        btnParqueo.setBackground(new java.awt.Color(163, 238, 201));
        btnParqueo.setText("Parqueo");
        btnParqueo.setBorder(null);
        btnParqueo.setContentAreaFilled(false);
        btnParqueo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnParqueoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sss, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnAreasRecreacion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 357, Short.MAX_VALUE)
            .addComponent(btnSalaPesas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnAuditorioFitnes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnCabinaInsonorizada, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnClaesGrupales, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnSocios, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(btnParqueo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(sss, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addComponent(btnSocios, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnClaesGrupales, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCabinaInsonorizada, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAuditorioFitnes, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSalaPesas, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAreasRecreacion, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(127, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(136, 136, 136)
                    .addComponent(btnParqueo, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(519, Short.MAX_VALUE)))
        );

        tablaClases.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Nombre", "Horario", "Cupos Disponibles"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaClases.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaClasesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaClases);
        if (tablaClases.getColumnModel().getColumnCount() > 0) {
            tablaClases.getColumnModel().getColumn(0).setResizable(false);
            tablaClases.getColumnModel().getColumn(1).setResizable(false);
            tablaClases.getColumnModel().getColumn(2).setResizable(false);
        }

        jLabel1.setText("ID del socio:");

        jLabel2.setText("Nombre de la clase:");

        jButton1.setText("Inscribir");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Cancelar suscripcion");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jToggleButton1.setText("Socios inscritos");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnMinimi)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSalir)
                        .addGap(11, 11, 11))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 655, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtIdSocio, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(36, 36, 36)
                                        .addComponent(jLabel2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(53, 53, 53)
                                        .addComponent(jButton2)))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jToggleButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNombreClase, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(140, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSalir)
                            .addComponent(btnMinimi)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombreClase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(txtIdSocio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jToggleButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(142, 142, 142))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMinimiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMinimiActionPerformed
        setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_btnMinimiActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnSociosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSociosActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsSocios socios = new WindowsSocios(gestor);
        socios.setVisible(true);
    }//GEN-LAST:event_btnSociosActionPerformed

    private void sssActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sssActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsParqueo parqueo = new WindowsParqueo(gestor);
        parqueo.setVisible(true);
    }//GEN-LAST:event_sssActionPerformed

    private void btnAreasRecreacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAreasRecreacionActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsSalasDeRecreacion recreacion = new WindowsSalasDeRecreacion(gestor);
        recreacion.setVisible(true);
    }//GEN-LAST:event_btnAreasRecreacionActionPerformed

    private void btnSalaPesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalaPesasActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsSalaDePesas pesas = new WindowsSalaDePesas(gestor);
        pesas.setVisible(true);
    }//GEN-LAST:event_btnSalaPesasActionPerformed

    private void btnAuditorioFitnesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAuditorioFitnesActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsAuditorioFitnes audiroio = new WindowsAuditorioFitnes(gestor);
        audiroio.setVisible(true);
    }//GEN-LAST:event_btnAuditorioFitnesActionPerformed

    private void btnCabinaInsonorizadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCabinaInsonorizadaActionPerformed
        this.dispose(); // Esto cierra la ventana actual
        WindowsCabinasInsonorizadas cabina = new WindowsCabinasInsonorizadas(gestor);
        cabina.setVisible(true);
    }//GEN-LAST:event_btnCabinaInsonorizadaActionPerformed

    private void btnClaesGrupalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClaesGrupalesActionPerformed
        ModuloClaseGrupales.ejecutar(gestor);
    }//GEN-LAST:event_btnClaesGrupalesActionPerformed

    private void btnParqueoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnParqueoActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsParqueo parqueo = new WindowsParqueo(gestor);
        parqueo.setVisible(true);
    }//GEN-LAST:event_btnParqueoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String idSocio = txtIdSocio.getText().trim();
        int selectedRow = tablaClases.getSelectedRow();
        if (idSocio.isEmpty()) {
            JOptionPane.showMessageDialog(this, " ingrese el ID del socio.", "", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, " seleccione una clase de la tabla.", "", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String nombreClase = (String) tablaClases.getValueAt(selectedRow, 0); // Obtener nombre de la clase de la tabla
        // Validar que el socio exista
        if (!gestor.verificarID(idSocio)) {
            JOptionPane.showMessageDialog(this, "El ID de socio no existe.", "", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Buscar la clase en el gestor
        ClaseGrupal claseSeleccionada = gestor.buscarClase(nombreClase);
        if (claseSeleccionada != null) {
            if (claseSeleccionada.registrarSocio(idSocio)) {
                JOptionPane.showMessageDialog(this, "Socio inscrito correctamente en " + nombreClase + ".");
                 actualizarTablaClases(); // Método para refrescar la tabla
            } else {
            }
        } else {
            JOptionPane.showMessageDialog(this, "Clase no encontrada", "", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String idSocio = txtIdSocio.getText().trim();
        int selectedRow = tablaClases.getSelectedRow();
        if (idSocio.isEmpty()) {
            JOptionPane.showMessageDialog(this, "ingrese el ID del socio", "", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione una clase de la tabla.", "", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String nombreClase = (String) tablaClases.getValueAt(selectedRow, 0);
        ClaseGrupal claseSeleccionada = gestor.buscarClase(nombreClase);
        if (claseSeleccionada != null) {
            if (claseSeleccionada.cancelarReserva(idSocio)) {
                JOptionPane.showMessageDialog(this, "Inscripción cancelada correctamente en " + nombreClase + ".");
                actualizarTablaClases();
            } else {
                // El mensaje de error ya lo maneja ClaseGrupal.cancelarReserva()
            }
        } else {
            JOptionPane.showMessageDialog(this, "Clase no encontrada.", "", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        int selectedRow = tablaClases.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una clase de la tabla para ver los inscritos.", "", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String nombreClase = (String) tablaClases.getValueAt(selectedRow, 0);
        ClaseGrupal claseSeleccionada = gestor.buscarClase(nombreClase);
        if (claseSeleccionada != null) {
            claseSeleccionada.mostrarInscritos(); // Este método ya usa JOptionPane
        } else {
            JOptionPane.showMessageDialog(this, "Clase no encontrada.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void tablaClasesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaClasesMouseClicked
        int selectedRow = tablaClases.getSelectedRow();
        if (selectedRow != -1) {
            String nombreClase = (String) tablaClases.getValueAt(selectedRow, 0);
            txtNombreClase.setText(nombreClase);
        }
    }//GEN-LAST:event_tablaClasesMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAreasRecreacion;
    private javax.swing.JButton btnAuditorioFitnes;
    private javax.swing.JButton btnCabinaInsonorizada;
    private javax.swing.JButton btnClaesGrupales;
    private javax.swing.JButton btnMinimi;
    private javax.swing.JButton btnParqueo;
    private javax.swing.JButton btnSalaPesas;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnSocios;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JButton sss;
    private javax.swing.JTable tablaClases;
    private javax.swing.JTextField txtIdSocio;
    private javax.swing.JTextField txtNombreClase;
    // End of variables declaration//GEN-END:variables
}
