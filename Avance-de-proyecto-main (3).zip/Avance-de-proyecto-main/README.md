# Avance-de-proyecto
Grupo 2 Introduccion a la programacion 
Integrantes:
Jose David Gutierrez Diaz
Rolando Marti Mejia
Arias Morera Ana Virginia
Solis Loghan Sebastian
