package gimnasio;

import javax.swing.JOptionPane;

public class GestorDeInstancias {

    public GestorDeInstancias() {
    }

    CabinaInsonorizada cabina[] = new CabinaInsonorizada[9];
    ClaseGrupal[] claseGrupal = new ClaseGrupal[6];
    Socio[] socios = new Socio[10];

    public void cargas() {
        int opcHorarioCabinas = CabinaInsonorizada.MostrarHorariosCabinas(cabina);
        CabinaInsonorizada.reservarHorario(cabina, opcHorarioCabinas);
    }

    public void llenaDataAleatoria(CabinaInsonorizada[] vector) {
        for (int i = 0; i < vector.length; i++) {
            vector[i] = new CabinaInsonorizada(true, i + 9 + ":" + "00", "-/-");
        }
    }

    public void cargarSocios() {
        System.out.println("gimnasio.GestorDeInstancias.cargarSocios()");
        socios[0] = new Socio("S001", "Carlos Gomez", true);
        socios[1] = new Socio("S002", "Ana Ruiz", true);
        socios[2] = new Socio("S003", "Luis Torres", false);
        socios[3] = new Socio("S004", "Maria Solis", true);
    }
    public boolean verificarID(String idSocio) {
        for (int i = 0; i < socios.length; i++) {
            if (socios[i] != null && idSocio.equals(socios[i].getId())) {
                return true;
            }
        }
        return false;
    }

    public Socio buscarSocio(String id) {
        for (int i = 0; i < socios.length; i++) {
            if (socios[i].getId().equals(id)) {
                return socios[i];
            }
        }
        return null;
    }
    
    

    
    
    public Socio[] getSocios() {
    return socios;
    }

    public ClaseGrupal[] getClaseGrupal() {
        return claseGrupal;
    }

    public void setClaseGrupal(ClaseGrupal[] claseGrupal) {
        this.claseGrupal = claseGrupal;
    }

    public CabinaInsonorizada[] getCabina() {
        return cabina;
    }
    
    public void setCabina(CabinaInsonorizada[] cabina) {
    this.cabina = cabina;
    }
      @Override
    public String toString() {
        return "GestorDeInstancias{" + "cabina=" + cabina + ", claseGrupal=" + claseGrupal + ", socios=" + socios + '}';
    }

}
