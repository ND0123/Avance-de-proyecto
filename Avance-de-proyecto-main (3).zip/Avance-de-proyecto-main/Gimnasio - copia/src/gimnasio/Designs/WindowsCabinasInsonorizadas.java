
package gimnasio.Designs;

import gimnasio.CabinaInsonorizada;
import static gimnasio.Designs.MainWindows.gestor;
import gimnasio.GestorDeInstancias;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * Creates new form WindowsCabinasInsonorizadas
 */

public class WindowsCabinasInsonorizadas extends javax.swing.JFrame {

    GestorDeInstancias gestor;

    public WindowsCabinasInsonorizadas(GestorDeInstancias gestor) {
        this.gestor = gestor;
        setUndecorated(true); // quita la barra superior y bordes del sistema

        // Inicializar los componentes de la ventana
        initComponents();
        agregarTodasLasCabinas(tablaCabinas, gestor.getCabina());

        // Centrar la ventana
        setLocationRelativeTo(null); // opcional: centrar ventana

        // Hacer visible
        setVisible(true);

        // Aplicar forma redondeada (después de visible)
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 60, 60));
        btnSalir.addActionListener(e -> dispose());

    }

    private void agregarTodasLasCabinas(JTable tabla, CabinaInsonorizada[] cabinas) {
        for (CabinaInsonorizada cabina : cabinas) {
            agregarFilaCabina(tabla, cabina);
        }
    }

    private void agregarFilaCabina(JTable tabla, CabinaInsonorizada cabinaInsonorizada) {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.addRow(new Object[]{
            modelo.getRowCount()+1,
            cabinaInsonorizada.getHoraReserva(),
            cabinaInsonorizada.getEstado() ? "Libre" : "Reservado",
            cabinaInsonorizada.getId()

        });
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSalir = new javax.swing.JButton();
        btnMinimi = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        btnClaesGrupales = new javax.swing.JButton();
        btnCabinaInsonorizada = new javax.swing.JButton();
        btnAuditorioFitnes = new javax.swing.JButton();
        btnSalaPesas = new javax.swing.JButton();
        btnAreasRecreacion = new javax.swing.JButton();
        btnParqueo = new javax.swing.JButton();
        btnSocios = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCabinas = new javax.swing.JTable();
        txtIDsocio = new javax.swing.JTextField();
        txtNumHorario = new javax.swing.JTextField();
        btnReservar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnSalir.setText("salir");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnMinimi.setText("minimi");
        btnMinimi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMinimiActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(171, 251, 211));

        btnClaesGrupales.setText("Clases Grupales");
        btnClaesGrupales.setBorder(null);
        btnClaesGrupales.setContentAreaFilled(false);
        btnClaesGrupales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClaesGrupalesActionPerformed(evt);
            }
        });

        btnCabinaInsonorizada.setBackground(new java.awt.Color(163, 238, 201));
        btnCabinaInsonorizada.setText("Cabinas Insonorizada");
        btnCabinaInsonorizada.setBorder(null);
        btnCabinaInsonorizada.setContentAreaFilled(false);
        btnCabinaInsonorizada.setOpaque(true);
        btnCabinaInsonorizada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCabinaInsonorizadaActionPerformed(evt);
            }
        });

        btnAuditorioFitnes.setText("Auditorio Fitnes");
        btnAuditorioFitnes.setBorder(null);
        btnAuditorioFitnes.setContentAreaFilled(false);
        btnAuditorioFitnes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuditorioFitnesActionPerformed(evt);
            }
        });

        btnSalaPesas.setText("Sala De Pesas");
        btnSalaPesas.setBorder(null);
        btnSalaPesas.setContentAreaFilled(false);
        btnSalaPesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalaPesasActionPerformed(evt);
            }
        });

        btnAreasRecreacion.setText("Espacios De Recreación");
        btnAreasRecreacion.setBorder(null);
        btnAreasRecreacion.setContentAreaFilled(false);
        btnAreasRecreacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAreasRecreacionActionPerformed(evt);
            }
        });

        btnParqueo.setBackground(new java.awt.Color(171, 251, 211));
        btnParqueo.setText("Parqueo");
        btnParqueo.setBorder(null);
        btnParqueo.setContentAreaFilled(false);
        btnParqueo.setOpaque(true);
        btnParqueo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnParqueoActionPerformed(evt);
            }
        });

        btnSocios.setText("Socios");
        btnSocios.setBorder(null);
        btnSocios.setContentAreaFilled(false);
        btnSocios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSociosActionPerformed(evt);
            }
        });

        jLabel1.setText("Cabina insonorizada");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnParqueo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(131, 131, 131)
                .addComponent(jLabel1)
                .addContainerGap(132, Short.MAX_VALUE))
            .addComponent(btnAreasRecreacion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnSalaPesas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnAuditorioFitnes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnCabinaInsonorizada, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnClaesGrupales, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnSocios, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel1)
                .addGap(35, 35, 35)
                .addComponent(btnParqueo, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(btnSocios, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnClaesGrupales, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCabinaInsonorizada, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAuditorioFitnes, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSalaPesas, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAreasRecreacion, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(127, Short.MAX_VALUE))
        );

        tablaCabinas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Num. Horario", "Hora", "Estado", "ID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaCabinas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaCabinasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaCabinas);

        txtNumHorario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumHorarioActionPerformed(evt);
            }
        });

        btnReservar.setText("Reservar");
        btnReservar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservarActionPerformed(evt);
            }
        });

        jLabel2.setText("ID de Socio");

        jLabel3.setText("Numero de Horario");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnMinimi)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSalir)
                        .addGap(11, 11, 11))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(111, 111, 111)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(26, 26, 26)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtNumHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txtIDsocio, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(53, 53, 53)
                                .addComponent(btnReservar, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(323, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 633, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(129, Short.MAX_VALUE))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalir)
                    .addComponent(btnMinimi))
                .addGap(183, 183, 183)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIDsocio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReservar)
                    .addComponent(txtNumHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnMinimiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMinimiActionPerformed
        setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_btnMinimiActionPerformed

    private void btnClaesGrupalesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClaesGrupalesActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsClasesGrupales clases = new WindowsClasesGrupales(gestor);
        clases.setVisible(true);
    }//GEN-LAST:event_btnClaesGrupalesActionPerformed

    private void btnCabinaInsonorizadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCabinaInsonorizadaActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsCabinasInsonorizadas cabina = new WindowsCabinasInsonorizadas(gestor);
        cabina.setVisible(true);

        //        CabinaInsonorizada.llenaDataAleatoria(cabina);
        //        int opcHorarioCabinas = CabinaInsonorizada.MostrarHorariosCabinas(gimnasio.Gimnasio.instancioas());
        //        CabinaInsonorizada.reservarHorario(gimnasio.Gimnasio.instancioas(), opcHorarioCabinas);

    }//GEN-LAST:event_btnCabinaInsonorizadaActionPerformed

    private void btnAuditorioFitnesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAuditorioFitnesActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsAuditorioFitnes audiroio = new WindowsAuditorioFitnes(gestor);
        audiroio.setVisible(true);
    }//GEN-LAST:event_btnAuditorioFitnesActionPerformed

    private void btnSalaPesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalaPesasActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsSalaDePesas pesas = new WindowsSalaDePesas(gestor);
        pesas.setVisible(true);
    }//GEN-LAST:event_btnSalaPesasActionPerformed

    private void btnAreasRecreacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAreasRecreacionActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsSalasDeRecreacion recreacion = new WindowsSalasDeRecreacion(gestor);
        recreacion.setVisible(true);
    }//GEN-LAST:event_btnAreasRecreacionActionPerformed

    private void btnParqueoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnParqueoActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsParqueo parqueo = new WindowsParqueo(gestor);
        parqueo.setVisible(true);
    }//GEN-LAST:event_btnParqueoActionPerformed

    private void btnSociosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSociosActionPerformed
        // TODO add your handling code here:
        this.dispose(); // Esto cierra la ventana actual
        WindowsSocios socios = new WindowsSocios(gestor);
        socios.setVisible(true);
    }//GEN-LAST:event_btnSociosActionPerformed

    private void txtNumHorarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumHorarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumHorarioActionPerformed

    private void btnReservarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservarActionPerformed
        // TODO add your handling code here:    
        try {
            int numHorario = Integer.parseInt(txtNumHorario.getText());
            if (numHorario > 9 || numHorario < 1) {
                JOptionPane.showMessageDialog(null, "Numero de horario invalido, solo se aceptan numeros del 1 al 9");
            }else{   
                if (gestor.verificarID(txtIDsocio.getText())) {
                    gestor.getCabina()[numHorario-1].setEstado(false);
                    gestor.getCabina()[numHorario-1].setId(txtIDsocio.getText());
                    DefaultTableModel model = (DefaultTableModel) tablaCabinas.getModel();
                    model.setRowCount(0);  // Esto elimina todas las filas
                    agregarTodasLasCabinas(tablaCabinas, gestor.getCabina());   
                }else{
                    JOptionPane.showMessageDialog(null, "ID de socio no encontrado");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Numero de horario invalido, solo se aceptan numeros");
        }
    }//GEN-LAST:event_btnReservarActionPerformed

    private void tablaCabinasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaCabinasMouseClicked
        int indiceTabla = tablaCabinas.getSelectedRow();
        int varTemp = (int) tablaCabinas.getValueAt(indiceTabla, 0);
        String numHorario = Integer.toString(varTemp);
        txtNumHorario.setText(numHorario);
    }//GEN-LAST:event_tablaCabinasMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAreasRecreacion;
    private javax.swing.JButton btnAuditorioFitnes;
    private javax.swing.JButton btnCabinaInsonorizada;
    private javax.swing.JButton btnClaesGrupales;
    private javax.swing.JButton btnMinimi;
    private javax.swing.JButton btnParqueo;
    private javax.swing.JButton btnReservar;
    private javax.swing.JButton btnSalaPesas;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnSocios;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaCabinas;
    private javax.swing.JTextField txtIDsocio;
    private javax.swing.JTextField txtNumHorario;
    // End of variables declaration//GEN-END:variables
}
