/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gimnasio;

import javax.swing.JOptionPane;

public class ModuloRecreacion {

    private String idEspacio;
    private String tipoEspacio;
    private int capacidadMaxima;
    private String[] ocupantes;
    private int cantidadActualOcupantes;

    public ModuloRecreacion(String idEspacio, String tipoEspacio, int capacidadMaxima) {
        this.idEspacio = idEspacio;
        this.tipoEspacio = tipoEspacio;
        this.capacidadMaxima = capacidadMaxima;
        this.ocupantes = new String[capacidadMaxima];
        this.cantidadActualOcupantes = 0;
    }

    public String getIdEspacio() {
        return idEspacio;
    }

    public void setIdEspacio(String idEspacio) {
        this.idEspacio = idEspacio;
    }

    public String getTipoEspacio() {
        return tipoEspacio;
    }

    public void setTipoEspacio(String tipoEspacio) {
        this.tipoEspacio = tipoEspacio;
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public void setCapacidadMaxima(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
    }

    public String[] getOcupantes() {
        return ocupantes;
    }

    public void setOcupantes(String[] ocupantes) {
        this.ocupantes = ocupantes;
    }

    public int getCantidadActualOcupantes() {
        return cantidadActualOcupantes;
    }

    // Método para registrar un socio en el espacio
    public boolean registrarSocio(String idSocio) {
        if (cantidadActualOcupantes >= capacidadMaxima) {
            JOptionPane.showMessageDialog(null, "El espacio de recreación '" + tipoEspacio + "' está lleno.");
            return false;
        }
        for (int i = 0; i < cantidadActualOcupantes; i++) {
            if (ocupantes[i] != null && ocupantes[i].equals(idSocio)) {
                JOptionPane.showMessageDialog(null, "Este socio ya está registrado en el espacio '" + tipoEspacio + "'.");
                return false;
            }
        }
        ocupantes[cantidadActualOcupantes] = idSocio;
        cantidadActualOcupantes++;
        JOptionPane.showMessageDialog(null, "Socio " + idSocio + " registrado correctamente en el espacio '" + tipoEspacio + "'.");
        return true;
    }

    public boolean retirarSocio(String idSocio) {
        for (int i = 0; i < cantidadActualOcupantes; i++) {
            if (ocupantes[i] != null && ocupantes[i].equals(idSocio)) {
                // Mover los elementos para llenar el hueco
                for (int j = i; j < cantidadActualOcupantes - 1; j++) {
                    ocupantes[j] = ocupantes[j + 1];
                }
                ocupantes[cantidadActualOcupantes - 1] = null; // Limpiar la última posición
                cantidadActualOcupantes--;
                JOptionPane.showMessageDialog(null, "Socio " + idSocio + " retirado correctamente del espacio '" + tipoEspacio + "'.");
                return true;
            }
        }
        JOptionPane.showMessageDialog(null, "El socio " + idSocio + " no está registrado en el espacio '" + tipoEspacio + "'.");
        return false;
    }

    // Método para mostrar los ocupantes del espacio
    public void mostrarOcupantes(Socio[] socios) { // Se necesita la lista de socios para buscar nombres
        if (cantidadActualOcupantes == 0) {
            JOptionPane.showMessageDialog(null, "No hay socios ocupando el espacio '" + tipoEspacio + "'.");
            return;
        }
        StringBuilder lista = new StringBuilder("Ocupantes del espacio '" + tipoEspacio );
        for (int i = 0; i < cantidadActualOcupantes; i++) {
            String id = ocupantes[i];
            String nombre = buscarNombrePorID(id, socios); 
            lista.append("- ").append(id).append(" (").append(nombre);
        }
        JOptionPane.showMessageDialog(null, lista.toString());
    }

    private String buscarNombrePorID(String id, Socio[] socios) {
        for (int i = 0; i < socios.length; i++) {
            if (socios[i] != null && socios[i].getId().equals(id)) {
                return socios[i].getNombre();
            }
        }
        return "Nombre no encontrado";
    }

    @Override
    public String toString() {
        return "EspacioRecreacion{" + "idEspacio=" + idEspacio + ", tipoEspacio=" + tipoEspacio + ", capacidadMaxima=" + capacidadMaxima + ", cantidadActualOcupantes=" + cantidadActualOcupantes + '}';
    }
}


/* BORRAR ... 

 

public static void ejecutar(GestorDeInstancias gestor) {
        while (true) {
            String in = JOptionPane.showInputDialog(
                "ESPACIO DE RECREACIÓN\n\n" +
                "1. Reservar mesa de ping-pong\n" +
                "2. Reservar mesa de billar\n" +
                "3. Ver disponibilidad de mesas\n" +
                "4. Ingresar a cancha de fútbol\n" +
                "5. Ingresar a cancha de baloncesto\n" +
                "6. Ingresar a cancha de tenis\n" +
                "7. Ver estado de canchas\n" +
                "0. Volver"
            );
            if (in == null || in.trim().equals("0")) return;

            switch (in.trim()) {
                case "1":
                    reservarMesa(gestor, 0); // ping-pong
                    break;
                case "2":
                    reservarMesa(gestor, 1); // billar
                    break;
                case "3":
                    mostrarMesas(gestor);
                    break;
                case "4":
                    ingresarFutbol(gestor);
                    break;
                case "5":
                    ingresarBaloncesto(gestor);
                    break;
                case "6":
                    ingresarTenis(gestor);
                    break;
                case "7":
                    mostrarCanchas(gestor);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        }
    }

    private static void reservarMesa(GestorDeInstancias gestor, int tipoMesa) {
        
        String s = JOptionPane.showInputDialog("Seleccione turno (1-4):");
        if (s == null) return;
        try {
            int turno = Integer.parseInt(s.trim()) - 1;
            if (turno < 0 || turno >= 4) {
                JOptionPane.showMessageDialog(null, "Turno inválido.");
                return;
            }
            boolean[][] mesas = gestor.getMesas();
            if (!mesas[tipoMesa][turno]) {
                mesas[tipoMesa][turno] = true;
                JOptionPane.showMessageDialog(null, "Turno reservado exitosamente.");
            } else {
                JOptionPane.showMessageDialog(null, "Turno no disponible.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida.");
        }
    }

    private static void mostrarMesas(GestorDeInstancias gestor) {
        boolean[][] mesas = gestor.getMesas();
    StringBuilder sb = new StringBuilder("Disponibilidad de mesas:\n");
    for (int i = 0; i < 4; i++) {
        sb.append("Turno ").append(i + 1).append(":\n");

        String estadoPing = mesas[0][i] ? "Reservado" : "Disponible"; 
        

        String estadoBillar = mesas[1][i] ? "Reservado" : "Disponible"; 
       

        sb.append("  Ping-pong: ").append(estadoPing).append("\n");
        sb.append("  Billar   : ").append(estadoBillar).append("\n");
    }
    JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void ingresarFutbol(GestorDeInstancias gestor) {
        String s = JOptionPane.showInputDialog("Ingrese número de cancha de fútbol (1 o 2):");
        if (s == null) return;
        try {
            int cancha = Integer.parseInt(s.trim()) - 1;
            if (cancha < 0 || cancha >= 2) {
                JOptionPane.showMessageDialog(null, "Cancha inválida.");
                return;
            }
            int[] futbol = gestor.getFutbol();
            if (futbol[cancha] < 12) {
                futbol[cancha]++;
                JOptionPane.showMessageDialog(null, "Ingresado a cancha de fútbol " + (cancha + 1));
            } else {
                JOptionPane.showMessageDialog(null, "Cancha llena.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida.");
        }
    }

    private static void ingresarBaloncesto(GestorDeInstancias gestor) {
        int actual = gestor.getBaloncesto();
        if (actual < 10) {
            gestor.setBaloncesto(actual + 1);
            JOptionPane.showMessageDialog(null, "Ingresado a cancha de baloncesto.");
        } else {
            JOptionPane.showMessageDialog(null, "Cancha llena.");
        }
    }

    private static void ingresarTenis(GestorDeInstancias gestor) {
        String s = JOptionPane.showInputDialog("Ingrese número de cancha de tenis (1 o 2):");
        if (s == null) return;
        try {
            int cancha = Integer.parseInt(s.trim()) - 1;
            if (cancha < 0 || cancha >= 2) {
                JOptionPane.showMessageDialog(null, "Cancha inválida.");
                return;
            }
            int[] tenis = gestor.getTenis();
            if (tenis[cancha] < 2) {
                tenis[cancha]++;
                JOptionPane.showMessageDialog(null, "Ingresado a cancha de tenis " + (cancha + 1));
            } else {
                JOptionPane.showMessageDialog(null, "Cancha llena.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida.");
        }
    }

    private static void mostrarCanchas(GestorDeInstancias gestor) {
        int[] futbol = gestor.getFutbol();
        int baloncesto = gestor.getBaloncesto();
        int[] tenis = gestor.getTenis();

        String estado = "Fútbol:\n"
            + "  Cancha 1: " + futbol[0] + "/12 jugadores\n"
            + "  Cancha 2: " + futbol[1] + "/12 jugadores\n\n"
            + "Baloncesto:\n"
            + "  Cancha: " + baloncesto + "/10 jugadores\n\n"
            + "Tenis:\n"
            + "  Cancha 1: " + tenis[0] + "/2 jugadores\n"
            + "  Cancha 2: " + tenis[1] + "/2 jugadores";
        JOptionPane.showMessageDialog(null, estado);
    }  

}
 */
