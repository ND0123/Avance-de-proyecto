package gimnasio;

//import static gimnasio.Gimnasio.gestor;
import java.net.IDN;
import javax.swing.JOptionPane;

public class GestorDeInstancias {

    CabinaInsonorizada cabina[] = new CabinaInsonorizada[9];
    ClaseGrupal[] claseGrupal = new ClaseGrupal[6];
    public static Socio[] socios = new Socio[10];
    private Auditorio[] sesionesAuditorio;
    private Parqueo parqueo = new Parqueo();
    private SalaPesas salaPesas;

    private ModuloRecreacion[] espaciosRecreacion;
    private boolean[][] mesas = new boolean[2][4]; // [0]=ping-pong, [1]=billar; 4 turnos
    private int[] futbol = new int[2];             // dos canchas, máx 12 
    private int baloncesto = 0;                    // una cancha, máx 10
    private int[] tenis = new int[2];              // dos canchas, máx 2 

    public GestorDeInstancias() {
        claseGrupal[0] = new ClaseGrupal("Yoga", "Lunes 9:00 AM", 1);
        claseGrupal[1] = new ClaseGrupal("Crossfit", "Martes 7:00 AM", 2);
        claseGrupal[2] = new ClaseGrupal("Funcionales", "Miércoles 6:00 PM", 3);
        claseGrupal[3] = new ClaseGrupal("Pilates", "Jueves 8:00 AM", 4);
        claseGrupal[4] = new ClaseGrupal("Zumba", "Viernes 7:00 PM", 5);
        claseGrupal[5] = new ClaseGrupal("Spinning", "Sábado 10:00 AM", 6);
        sesionesAuditorio = new Auditorio[30];
        sesionesAuditorio[0] = new Auditorio("9:00 AM");
        sesionesAuditorio[1] = new Auditorio("1:00 PM");
        sesionesAuditorio[2] = new Auditorio("5:00 PM");

        this.salaPesas = new SalaPesas(50);

        this.espaciosRecreacion = new ModuloRecreacion[100]; // Por ejemplo, 5 espacios
        inicializarEspaciosRecreacion(); // Método para poblar los espacios
    }

    private void inicializarEspaciosRecreacion() {
        espaciosRecreacion[0] = new ModuloRecreacion("ESP1", "Cancha de Baloncesto", 1);
        espaciosRecreacion[1] = new ModuloRecreacion("ESP2", "Sala de Yoga", 2);
        espaciosRecreacion[2] = new ModuloRecreacion("ESP3", "Piscina", 3);
        espaciosRecreacion[3] = new ModuloRecreacion("ESP4", "Sala de Juegos", 4);
        espaciosRecreacion[4] = new ModuloRecreacion("ESP5", "Pista de Atletismo", 5);
    }
    // Metodo para buscar un espacio de recreación por su ID

    public ModuloRecreacion buscarEspacioRecreacion(String idEspacio) {
        for (ModuloRecreacion espacio : espaciosRecreacion) {
            if (espacio != null && espacio.getIdEspacio().equalsIgnoreCase(idEspacio)) {
                return espacio;
            }
        }
        return null;
    }

    public ModuloRecreacion[] getEspaciosRecreacion() {
        return espaciosRecreacion;
    }

    public boolean[][] getMesas() {
        return mesas;
    }

    public void setMesas(boolean[][] mesas) {
        this.mesas = mesas;
    }

    public int[] getFutbol() {
        return futbol;
    }

    public void setFutbol(int[] futbol) {
        this.futbol = futbol;
    }

    public int getBaloncesto() {
        return baloncesto;
    }

    public void setBaloncesto(int baloncesto) {
        this.baloncesto = baloncesto;
    }

    public int[] getTenis() {
        return tenis;
    }

    public void setTenis(int[] tenis) {
        this.tenis = tenis;
    }

    public SalaPesas getSalaPesas() {
        return salaPesas;
    }

    public void setSalaPesas(SalaPesas salaPesas) {
        this.salaPesas = salaPesas;
    }

    public Parqueo getParqueo() {
        return parqueo;
    }

    public void setParqueo(Parqueo parqueo) {
        this.parqueo = parqueo;
    }

    public Auditorio[] getSesionesAuditorio() {
        return sesionesAuditorio;
    }

    public Auditorio buscarSesionAuditorio(String horario) {
        for (Auditorio sesion : sesionesAuditorio) {
            if (sesion != null && sesion.getHorario().equalsIgnoreCase(horario)) {
                return sesion;
            }
        }
        return null; // Sesión no encontrada
    }

    public void cargas() {
        int opcHorarioCabinas = CabinaInsonorizada.MostrarHorariosCabinas(cabina);
        CabinaInsonorizada.reservarHorario(cabina, opcHorarioCabinas);
    }

    public void llenaDataAleatoria(CabinaInsonorizada[] vector) {
        for (int i = 0; i < vector.length; i++) {
            vector[i] = new CabinaInsonorizada(true, i + 9 + ":" + "00", "-/-");
        }
    }

    public void cargarSocios() {
        System.out.println("gimnasio.GestorDeInstancias.cargarSocios()");
        socios[0] = new Socio("S001", "Carlos Gomez", true);
        socios[1] = new Socio("S002", "Ana Ruiz", true);
        socios[2] = new Socio("S003", "Luis Torres", false);
        socios[3] = new Socio("S004", "Maria Solis", true);
    }

    public boolean verificarID(String idSocio) {
        for (int i = 0; i < socios.length; i++) {
            if (socios[i] != null && idSocio.equals(socios[i].getId())) {
                return true;
            }
        }
        return false;
    }

    public Socio buscarSocio(String id) {
        for (int i = 0; i < socios.length; i++) {
            if (socios[i].getId().equals(id)) {
                return socios[i];
            }
        }
        return null;
    }

    public Socio[] getSocios() {
        return socios;
    }

    public ClaseGrupal[] getClaseGrupal() {
        return claseGrupal;
    }

    public void setClaseGrupal(ClaseGrupal[] claseGrupal) {
        this.claseGrupal = claseGrupal;
    }

    public CabinaInsonorizada[] getCabina() {
        return cabina;
    }

    public void setCabina(CabinaInsonorizada[] cabina) {
        this.cabina = cabina;
    }

    // ===== SOCIOS =====
    public String upsertSocio(String id, String nombre, boolean activo) {
        if (id == null || id.trim().isEmpty() || nombre == null || nombre.trim().isEmpty()) {
            return "Completa ID y Nombre.";
        }

        int libre = -1;
        for (int i = 0; i < socios.length; i++) {
            if (socios[i] == null && libre == -1) {
                libre = i;
            } else if (socios[i] != null && id.equals(socios[i].getId())) {
                socios[i].setNombre(nombre);
                socios[i].setActivo(activo);
                return "Socio actualizado.";
            }
        }
        if (libre != -1) {
            socios[libre] = new Socio(id, nombre, activo);
            return "Socio agregado.";
        }
        return "No hay espacio para más socios.";
    }

    public ClaseGrupal buscarClase(String nombreClase) {
        for (ClaseGrupal clase : claseGrupal) {
            if (clase != null && clase.getNombre().equalsIgnoreCase(nombreClase)) {
                return clase;
            }
        }
        return null;
    }
    // Inserta o actualiza una clase grupal identificada por (nombre + horario)

    public String upsertClaseGrupal(ClaseGrupal nueva) {
        if (nueva == null) {
            return "Datos inválidos.";
        }
        String nombre = nueva.getNombre();
        String horario = nueva.getHorario();
        if (nombre == null || nombre.trim().isEmpty() || horario == null || horario.trim().isEmpty()) {
            return "Completa Nombre y Horario.";
        }

        int libre = -1;
        for (int i = 0; i < claseGrupal.length; i++) {
            if (claseGrupal[i] == null && libre == -1) {
                libre = i;
            } else if (claseGrupal[i] != null
                    && nombre.equalsIgnoreCase(claseGrupal[i].getNombre())
                    && horario.equalsIgnoreCase(claseGrupal[i].getHorario())) {
                // ✅ Reemplaza la instancia completa
                claseGrupal[i] = nueva;
                return "Clase actualizada.";
            }
        }

        if (libre != -1) {
            claseGrupal[libre] = nueva;
            return "Clase agregada.";
        }
        return "No hay espacio para más clases.";
    }
    // ===== CLASES GRUPALES (por campos) =====
// ===== CLASES GRUPALES (por campos) =====

    public String upsertClaseGrupalPorCampos(String nombre, String horario, int capacidadMaxima) {
        if (nombre == null || nombre.trim().isEmpty() || horario == null || horario.trim().isEmpty()) {
            return "Completa Nombre y Horario.";
        }

        // Actualizar si ya existe (clave: nombre+horario)
        for (int i = 0; i < claseGrupal.length; i++) {
            if (claseGrupal[i] != null
                    && nombre.equalsIgnoreCase(claseGrupal[i].getNombre())
                    && horario.equalsIgnoreCase(claseGrupal[i].getHorario())) {

                // ✅ Reemplazamos la instancia con el constructor válido
                claseGrupal[i] = new ClaseGrupal(nombre, horario, capacidadMaxima);
                return "Clase actualizada.";
            }
        }

        // Insertar en primer espacio libre
        for (int i = 0; i < claseGrupal.length; i++) {
            if (claseGrupal[i] == null) {
                claseGrupal[i] = new ClaseGrupal(nombre, horario, capacidadMaxima);
                return "Clase agregada.";
            }
        }

        return "No hay espacio para más clases.";
    }

    public void registrar(String id, String nombre) {
        // String res = gestor.upsertSocio(id.trim(), nombre.trim(), true);
        //JOptionPane.showMessageDialog(null, res);

    }

    public void buscar(GestorDeInstancias gestor, String id) {

        if (id == null) {
            return;
        }
        Socio s = gestor.buscarSocio(id.trim());
        JOptionPane.showMessageDialog(null,
                s != null ? ("Socio: " + s.getNombre() + "\nActivo: " + (s.isActivo() ? "Sí" : "No"))
                        : "No encontrado.");
    }

    @Override
    public String toString() {
        return "GestorDeInstancias{" + "cabina=" + cabina + ", claseGrupal=" + claseGrupal + ", socios=" + socios + '}';
    }

}
