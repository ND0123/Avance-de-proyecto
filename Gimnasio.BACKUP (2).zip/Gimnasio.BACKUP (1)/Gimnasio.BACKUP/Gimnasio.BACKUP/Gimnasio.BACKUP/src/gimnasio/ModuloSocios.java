/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gimnasio;

import javax.swing.JOptionPane;

/**
 *
 * @author XPC
 */
public class ModuloSocios {
public static void ejecutar(GestorDeInstancias gestor) {
        int opcion = 0;
        do {
            String menu = JOptionPane.showInputDialog(
                "GESTIÓN DE SOCIOS\n\n" +
                "1. Ver todos\n" +
                "2. Buscar por ID\n" +
                "3. Registrar nuevo\n" +
                "4. Activar/Inactivar\n" +
                "0. Volver"
            );
            if (menu == null) {
                return;
            }

            try {
                opcion = Integer.parseInt(menu.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
                continue;
            }
            // Ejecutar la opción elegida
            switch (opcion) {
                case 1:
                    mostrarTodos(gestor);
                    break;
                case 2:
                    buscar(gestor);
                    break;
                case 3:
                    registrar(gestor);
                    break;
                case 4:
                    toggleEstado(gestor);
                    break;
                case 0:
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida.");
            }
        } while (opcion != 0);
    }
    // Mostrar todos los socios registrados
    private static void mostrarTodos(GestorDeInstancias gestor) {
        Socio[] socio = gestor.getSocios();
        StringBuilder sb = new StringBuilder("LISTA DE SOCIOS:\n");
        if (socio != null) {
            for (Socio s : socio) {
                if (s != null) {
                    sb.append(s.getId())
                      .append(" - ").append(s.getNombre())
                      .append(" - Activo: ");
                    if (s.isActivo()) {
                        sb.append("Sí");
                    } else {
                        sb.append("No");
                    }
                    sb.append("\n");
                }
            }
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }
    // Buscar un socio por su ID
    private static void buscar(GestorDeInstancias gestor) {
        String id = JOptionPane.showInputDialog("ID del socio:");
        if (id == null) {
            return;
        }
        Socio s = gestor.buscarSocio(id.trim());// Buscar socio por ID
        if (s != null) {
            StringBuilder info = new StringBuilder();
            info.append("Socio: ").append(s.getNombre()).append("\nActivo: ");
            if (s.isActivo()) {
                info.append("Sí");
            } else {
                info.append("No");
            }
            JOptionPane.showMessageDialog(null, info.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No encontrado.");
        }
    }
    // Registrar un nuevo socio
    private static void registrar(GestorDeInstancias gestor) {
        String id = JOptionPane.showInputDialog("Nuevo ID:");
        if (id == null) {
            return;
        }
        String nombre = JOptionPane.showInputDialog("Nombre:");
        if (nombre == null) {
            return;
        }
        // Registrar socio como activo
        String registro = gestor.upsertSocio(id.trim(), nombre.trim(), true);
        JOptionPane.showMessageDialog(null, registro);
    }
    // Cambiar el estado de un socio (activo o inactivo)
    private static void toggleEstado(GestorDeInstancias gestor) {
        String id = JOptionPane.showInputDialog("ID del socio:");
        if (id == null) {
            return;
        }
        Socio s = gestor.buscarSocio(id.trim());
        if (s == null) {
            JOptionPane.showMessageDialog(null, "Socio no encontrado.");
            return;
        }
        s.setActivo(!s.isActivo());

        StringBuilder msg = new StringBuilder("Ahora activo: ");
        if (s.isActivo()) {
            msg.append("Sí");
        } else {
            msg.append("No");
        }
        JOptionPane.showMessageDialog(null, msg.toString());
    }   
}
